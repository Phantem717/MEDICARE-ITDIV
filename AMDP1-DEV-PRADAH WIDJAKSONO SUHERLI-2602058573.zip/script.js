const HB = document.querySelector(".HB")
const Navmenu = document.querySelector(".Navmenu")

HB.addEventListener("click",() =>{
    HB.classList.toggle("active");
    HB.classList.toggle("active");
})